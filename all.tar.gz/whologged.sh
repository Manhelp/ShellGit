#!/bin/bash

cd 
. .bashrc
date
who
