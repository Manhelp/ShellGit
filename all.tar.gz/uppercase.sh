#!/bin/bash

tr 'a-z' 'A-Z'

exit 0
