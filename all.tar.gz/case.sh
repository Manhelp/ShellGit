#!/bin/bash
variable=abc
case "$variable" in
abc) echo "\$variable = abc";;
xyz) echo "\$variable = xyz";;
esac
